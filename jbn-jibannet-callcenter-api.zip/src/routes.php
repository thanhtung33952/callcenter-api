<?php

use Slim\Http\Request;
use Slim\Http\Response;


//*************** Begin API ChatTheme *********************
//Get all chattheme
$app->get('/chatthemes', 'ChatThemeController:getAllChatTheme');

//Get chattheme by Id
$app->get('/chattheme/[{id}]', 'ChatThemeController:getChatThemeById' );

// Add a new chattheme
$app->post('/chattheme', 'ChatThemeController:addNewChatTheme' );

// Update chattheme with Id
$app->put('/chattheme/[{id}]', 'ChatThemeController:updateChatThemeWithId' );

// delete a chattheme with Id
$app->delete('/chattheme/[{id}]', 'ChatThemeController:deleteChatThemeWithId' );
//*************** End API ChatTheme *********************

 
//*************** Begin API ChatUser *********************
//Get all chatuser
$app->get('/chatusers', 'ChatUserController:getAllChatUser');

//Get chatuser by Id
$app->get('/chatuser/[{id}]', 'ChatUserController:getChatUserById' );

// Add a new chatuser
$app->post('/chatuser', 'ChatUserController:addNewChatUser' );

// Update chatuser with Id
$app->put('/chatuser/[{id}]', 'ChatUserController:updateChatUserWithId' );

// delete a chatuser with Id
$app->delete('/chatuser/[{id}]', 'ChatUserController:deleteChatUserWithId' );
//*************** End API ChatUser *********************


//*************** Begin API Company *********************
//Get all company
$app->get('/companys', 'CompanyController:getAllCompany');

//Get company by Id
$app->get('/company/[{id}]', 'CompanyController:getCompanyById' );

// Add a new company
$app->post('/company', 'CompanyController:addNewCompany' );

// Update company with Id
$app->put('/company/[{id}]', 'CompanyController:updateCompanyWithId' );

// delete a company with Id
$app->delete('/company/[{id}]', 'CompanyController:deleteCompanyWithId' );
//*************** End API Company *********************


//*************** Begin API CentersStaff *********************
//Get all centersstaff
$app->get('/centersstaffs', 'CentersStaffController:getAllCentersStaff');

//Get centersstaff by Id
$app->get('/centersstaff/[{id}]', 'CentersStaffController:getCentersStaffById' );

// Add a new centersstaff
$app->post('/centersstaff', 'CentersStaffController:addNewCentersStaff' );

// Update centersstaff with Id
$app->put('/centersstaff/[{id}]', 'CentersStaffController:updateCentersStaffWithId' );

// delete a centersstaff with Id
$app->delete('/centersstaff/[{id}]', 'CentersStaffController:deleteCentersStaffWithId' );
//*************** End API CentersStaff *********************


//*************** Begin API Chat *********************
// //Get all chat
// $app->get('/chats', 'ChatController:getAllChat');

//Get chat by Id
$app->get('/chat/[{id}]', 'ChatController:getChatById' );

// Add a new chat
$app->post('/chat', 'ChatController:addNewChat' );

// Update chat with Id
$app->put('/chat/[{id}]', 'ChatController:updateChatWithId' );

// delete a chat with Id
$app->delete('/chat/[{id}]', 'ChatController:deleteChatWithId' );
//*************** End API Chat *********************


//*************** Begin API ChatManage *********************
//Get all chatmanage
$app->get('/chatmanages', 'ChatManageController:getAllChatManage');

//Get chatmanage by Id
$app->get('/chatmanage/[{id}]', 'ChatManageController:getChatManageById' );

// Add a new chatmanage
$app->post('/chatmanage', 'ChatManageController:addNewChatManage' );

// Update chatmanage with Id
$app->put('/chatmanage/[{id}]', 'ChatManageController:updateChatManageWithId' );

// delete a chatmanage with Id
$app->delete('/chatmanage/[{id}]', 'ChatManageController:deleteChatManageWithId' );
//*************** End API ChatManage *********************
