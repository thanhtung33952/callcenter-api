<?php
namespace Controllers;
use DateTime;
class ChatManageController
{
    private $db;

    // constructor receives container instance
    public function __construct($db) {
        $this->db = $db;
    }

    public function getAllChatManage($request, $response, $args) {
        try{
            $sql = "SELECT ChatManage.id, user_id, staff_id, theme_id, start, end  
                    FROM ChatManage 
                    INNER JOIN ChatUser 
                        ON user_id = ChatUser.id
                    INNER JOIN CentersStaff 
                        ON staff_id = CentersStaff.id
                    INNER JOIN ChatTheme 
                        ON theme_id = ChatTheme.id
                    ORDER BY ChatManage.id ";
            
            $limit = isset($_GET['limit']) ? $_GET['limit'] : 0;
            $offset= isset($_GET['offset']) ? $_GET['offset'] : 0;
            if($limit>0){
                $sql .= "LIMIT $limit OFFSET $offset ";
            }
    
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll();
            return $response->withJson($result);
        }
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }

    //Get ChatManage by userId
    public function getChatManageById($request, $response, $args) {
        $id = $args['id'];
        
        //get user
        $sql = "SELECT ChatManage.id, user_id, staff_id, theme_id, start, end  
                FROM ChatManage 
                INNER JOIN ChatUser 
                    ON user_id = ChatUser.id
                INNER JOIN CentersStaff 
                    ON staff_id = CentersStaff.id
                INNER JOIN ChatTheme 
                    ON theme_id = ChatTheme.id
                ORDER BY ChatManage.id 
                WHERE ChatManage.id=:id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam("id", $id);
        $stmt->execute();
        $result = $stmt->fetchObject();
        
        return $response->withJson($result);
    }

    // Add a new ChatManage
    public function addNewChatManage($request, $response) {
        $input = $request->getParsedBody();
        $user_id = $input['user_id'];
        $staff_id = $input['staff_id'];
        $theme_id = $input['theme_id'];
        
        $this->db->beginTransaction();
        try {
            
            $sql = "INSERT INTO ChatManage (user_id, staff_id, theme_id) 
                        VALUES (:user_id, :staff_id, :theme_id)";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam("user_id", $user_id);
            $stmt->bindParam("staff_id", $staff_id);
            $stmt->bindParam("theme_id", $theme_id);

    
            $stmt->execute();
            $input['id'] = $this->db->lastInsertId();
    
            $this->db->commit();

            return $response->withJson($input);
        }               
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            $this->db->rollback();
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }

    // Update user with userId
    public function updateChatManageWithUserId($request, $response, $args) {
        $input = $request->getParsedBody();
        $userId = $args['id'];
        $user_id = $input['user_id'];
        $staff_id = $input['staff_id'];
        $theme_id = $input['theme_id'];
    
        $this->db->beginTransaction();
        try {
            $sql = "UPDATE ChatManage SET user_id=:user_id, staff_id=:staff_id, theme_id=:theme_id 
                    WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam("user_id", $user_id);
            $stmt->bindParam("staff_id", $staff_id);
            $stmt->bindParam("theme_id", $theme_id);
            $stmt->bindParam("id", $id);
            $stmt->execute();            
            
            $this->db->commit();
            return $response->withJson($input);
        }               
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            $this->db->rollback();
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }

    // delete a user with Id
    public function deleteChatManageWithId($request, $response, $args) {
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare("DELETE FROM ChatManage WHERE id=:id");
            $stmt->bindParam("id", $args['id']);
            $result = $stmt->execute();
            
            $this->db->commit();
            return $response->withStatus(200);
        }               
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            $this->db->rollback();
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }
}