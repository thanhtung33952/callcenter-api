<?php
namespace Controllers;

class ChatThemeController
{
    private $db;

    // constructor receives container instance
    public function __construct($db) {
        $this->db = $db;
    }

    public function getAllChatTheme($request, $response, $args) {
        try{
            $sql = "SELECT id, name  
                    FROM ChatTheme 
                    ORDER BY name ";
            
            $limit = isset($_GET['limit']) ? $_GET['limit'] : 0;
            $offset= isset($_GET['offset']) ? $_GET['offset'] : 0;
            if($limit>0){
                $sql .= "LIMIT $limit OFFSET $offset ";
            }
    
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll();
            return $response->withJson($result);
        }
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }

    //Get ChatTheme by ChatThemeId
    public function getChatThemeById($request, $response, $args) {
        $id = $args['id'];
        
        //get ChatTheme
        $sql = "SELECT id, name 
                FROM ChatTheme WHERE id=:id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam("id", $id);
        $stmt->execute();
        $result = $stmt->fetchObject();
        
        return $response->withJson($result);
    }

    // Add a new ChatTheme
    public function addNewChatTheme($request, $response) {
        $input = $request->getParsedBody();
        $name = $input['name'];
    
        $this->db->beginTransaction();
        try {
            //check exist
            $sql = "SELECT name 
                    FROM ChatTheme 
                    WHERE name=:name";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam("name", $name);
            $stmt->execute();
            $result = $stmt->fetch();
            if($stmt->rowCount()>0){
                $input['id'] = -1;
                return $response->withJson($input);
            }

            //insert ChatTheme
            $sql = "INSERT INTO ChatTheme (name) 
                        VALUES (:name)";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam("name", $name);
    
            $stmt->execute();
            $input['id'] = $this->db->lastInsertId();
    
            $this->db->commit();
            return $response->withJson($input);
        }               
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            $this->db->rollback();
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }

    // Update ChatTheme with Id
    public function updateChatThemeWithId($request, $response, $args) {
        $input = $request->getParsedBody();
        $id = $args['id'];
        $name = $input['name'];
    
        $this->db->beginTransaction();
        try {
            $sql = "UPDATE ChatTheme SET name=:name 
                    WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam("name", $name);
            $stmt->bindParam("id", $id);
            $stmt->execute();
            
            $this->db->commit();
            return $response->withJson($input);
        }               
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            $this->db->rollback();
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }

    // delete a ChatTheme with Id
    public function deleteChatThemeWithId($request, $response, $args) {
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare("DELETE FROM ChatTheme WHERE id=:id");
            $stmt->bindParam("id", $args['id']);
            $result = $stmt->execute();
            
            $this->db->commit();
            return $response->withStatus(200);
        }               
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            $this->db->rollback();
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }
}