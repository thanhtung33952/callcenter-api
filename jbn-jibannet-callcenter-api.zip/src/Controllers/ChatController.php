<?php
namespace Controllers;
use DateTime;
class ChatController
{
    private $db;

    // constructor receives container instance
    public function __construct($db) {
        $this->db = $db;
    }

    //Get Chat by ChatId
    public function getChatById($request, $response, $args) {
        $chat_id = $args['id'];
        $sql = "SELECT id, chat_id, writer_id, time, text 
                FROM Chat 
                WHERE chat_id=:chat_id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam("chat_id", $chat_id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        
        return $response->withJson($result);
    }

    // Add a new Chat
    public function addNewChat($request, $response) {
        $input = $request->getParsedBody();
        $chat_id = $input['chat_id'];
        $writer_id = $input['writer_id'];
        $text = $input['text'];
        
        $this->db->beginTransaction();
        try {
            $sql = "INSERT INTO Chat (chat_id, writer_id, text) 
                        VALUES (:chat_id, :writer_id, :text)";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam("chat_id", $chat_id);
            $stmt->bindParam("writer_id", $writer_id);
            $stmt->bindParam("text", $text);
    
            $stmt->execute();
            $input['id'] = $this->db->lastInsertId();
    
            $this->db->commit();

            return $response->withJson($input);
        }               
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            $this->db->rollback();
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }

    // Update chat with ChatId
    public function updateChatWithId($request, $response, $args) {
        $input = $request->getParsedBody();
        $chat_id = $args['id'];
        $text = $input['text'];
    
        $this->db->beginTransaction();
        try {
            $sql = "UPDATE Chat SET text=:text  
                    WHERE chat_id = :chat_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam("text", $text);
            $stmt->bindParam("chat_id", $chat_id);
            $stmt->execute();
            
            $this->db->commit();
            return $response->withJson($input);
        }               
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            $this->db->rollback();
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }

    // delete a Chat with ChatId
    public function deleteChatWithId($request, $response, $args) {
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare("DELETE FROM Chat WHERE chat_id=:chat_id");
            $stmt->bindParam("chat_id", $args['id']);
            $result = $stmt->execute();
            
            $this->db->commit();
            return $response->withStatus(200);
        }               
        // any errors from the above database queries will be catched
        catch (PDOException $e){
            // roll back transaction
            $this->db->rollback();
            //return $response->write($e);
            return $response->withStatus(500);
            // log any errors to file
            ExceptionErrorHandler($e);
            exit;
        }
    }

    

    function generateId(){
        $date = new DateTime();
        $result = $date->format('Y-m-d H:i:s');
        $str = $this->generateRandomString().$result;
        return MD5($str);
    }
    
    function generateRandomString($length = 6) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}